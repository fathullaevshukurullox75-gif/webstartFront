<script setup lang="ts"></script>

<template>
    <div>
        <h2>Payment Page</h2>
    </div>
</template>

<style scoped></style>