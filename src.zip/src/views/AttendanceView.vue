<script setup lang="ts">

</script>

<template>
    <div>
        <h2>Attendance Page</h2>
    </div>
</template>


<style></style>