<script setup lang="ts">
import { ref, onMounted } from "vue";
import axios from "axios";
import { useAuthStore } from "@/stores/auth";

const users = ref<any[]>([]);
const API_URL = "http://localhost:4001/api/users";

// Hamma userlarni olish
const fetchUsers = async () => {
  try {
    const res = await axios.get(API_URL, {
      headers: { token: localStorage.getItem("token") },
    });
    users.value = res.data.users;
  } catch (err: any) {
    if (err.response?.data?.message === "jwt expired") {
      useAuthStore().logout();
    } else {
      console.error("Failed to fetch users", err);
    }
  }
};

onMounted(() => {
  fetchUsers();
});
</script>

<template>
  <div class="user-container">
    <div class="d-flex justify-content-between align-items-center ">
        <h2 class="title">All Users</h2>
        <button class="btn btn-success"> <i class="fa-solid fa-plus"></i> Add User</button>
    </div>

    <table class="user-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Role</th>
          <th>Created At</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(u, index) in users" :key="u._id">
          <td>{{ index + 1 }}</td>
          <td>{{ u.username }} {{ u.surname }}</td>
          <td>{{ u.email }}</td>
          <td>{{ u.phonenumber }}</td>
          <td>
            <span :class="'badge ' + u.role">{{ u.role }}</span>
          </td>
          <td>{{ u.createdAt?.slice(0,10) }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<style scoped>
.user-container {
  max-width: 1000px;
  margin: 30px auto;
  padding: 20px;
  background: #fff;
  border-radius: 12px;
  overflow-x: auto;
}

.title {
  font-size: 26px;
  font-weight: 700;
  text-align: center;
  margin-bottom: 20px;
  color: #2e7d32;
}

.user-table {
  width: 100%;
  border-collapse: collapse;
  min-width: 700px; 
}

.user-table th,
.user-table td {
  padding: 10px 14px;
  border: 1px solid #e0e0e0;
  text-align: left;
  font-size: 14px;
}

.user-table th {
  background: #f1f8f1;
  font-weight: 600;
}

.user-table tr:nth-child(even) {
  background: #fafafa;
}

.badge {
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
}

.badge.user {
  background: #2e7d32;
}
.badge.teacher {
  background: #1976d2;
}
.badge.admin {
  background: #f57c00;
}

/* 📱 Media: telefon ekranida */
@media (max-width: 768px) {
  .title {
    font-size: 20px;
  }

  .user-table th,
  .user-table td {
    padding: 8px;
    font-size: 12px;
  }

  .badge {
    font-size: 11px;
    padding: 3px 8px;
  }
}

@media (max-width: 480px) {
  .user-container {
    padding: 10px;
  }

  .title {
    font-size: 18px;
  }

  .user-table {
    min-width: 600px; /* scroll chiqadi */
  }
}
</style>

